#!/usr/bin/ruby
# CIT 383
# Lab 11
# Combs, Lucas

require_relative 'HealthProfile'

HealthProfile.new("Joseph", "Walden", "Male", 1983, 2018, 67, 175).displayHealthProfile()